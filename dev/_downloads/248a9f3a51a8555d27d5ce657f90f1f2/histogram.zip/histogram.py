"""
Histogram
=========

The :meth:`pygmt.Figure.histogram` method can plot regular histograms.
Using the ``series`` parameter allows to set the interval for the width of
each bar. The quantity each bar represents (a count or a percentage) can be
selected via the ``histtype`` parameter.
"""

# %%
import numpy as np
import pygmt
from pygmt.params import Axis, Frame

# Generate random elevation data from a normal distribution
rng = np.random.default_rng(seed=100)
mean = 100  # mean of distribution
stddev = 25  # standard deviation of distribution
data = rng.normal(loc=mean, scale=stddev, size=521)


fig = pygmt.Figure()

fig.histogram(
    data=data,
    # Define the frame, add a title, and set the background color to "lightgray".
    # Add labels to the x-axis and y-axis
    frame=Frame(
        axes="WSne",
        title="Histogram",
        fill="lightgray",
        xaxis=Axis(label="Elevation (m)"),
        yaxis=Axis(label="Counts"),
    ),
    # Generate evenly spaced bins by increments of 5
    series=5,
    # Use "red3" as color fill for the bars
    fill="red3",
    # Use the pen parameter to draw the outlines with a width of 1 point
    pen="1p",
)

fig.show()
