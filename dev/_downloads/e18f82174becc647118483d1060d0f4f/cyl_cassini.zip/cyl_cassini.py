r"""
Cassini cylindrical projection
==============================

This cylindrical projection was developed in 1745 by César-François Cassini de
Thury for the survey of France. It is occasionally called Cassini-Soldner since
the latter provided the more accurate mathematical analysis that led to the
development of the ellipsoidal formulae. The projection is neither conformal
nor equal-area, and behaves as a compromise between the two end-members. The
distortion is zero along the central meridian. It is best suited for mapping
regions of north-south extent. The central meridian, each meridian 90° away,
and equator are straight lines; all other meridians and parallels are complex
curves.

**c**\ *lon0/lat0*\ */scale* or **C**\ *lon0/lat0*\ */width*

- **c** or **C**: Sets the projection type.
- *lon0/lat0*: Sets the projection center.
- *scale* or *width*: Sets the map size.
"""

# %%
import pygmt
from pygmt.params import Axis

fig = pygmt.Figure()
# Use the ISO code for Madagascar (MG) and pad it by 2 degrees (+R2)
fig.coast(
    region="MG+R2",
    projection="C47/-19/12c",
    frame=Axis(annot=True, tick=True, grid=True),
    land="gray80",
    water="steelblue",
)
fig.show()
